<div class="row">
    <div  class="col-md-12">
        </br>
        <?php
                esc_html_e('AI Image Generator is available with the WPBot Pro versions');
        ?>
    </div>
</div>