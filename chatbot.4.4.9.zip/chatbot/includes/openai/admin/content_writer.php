<div class="row">
    <div  class="col-md-12 mt-3">
        </br>
        <?php
                esc_html_e('AI Article Generator is available with the WPBot Pro versions');
        ?>
    </div>
</div>